(function () {
  var btn = document.getElementById('themeToggle');
  var root = document.documentElement;

  function apply(mode) {
    if (mode === 'dark') {
      root.setAttribute('data-theme', 'dark');
      btn.textContent = 'Light mode';
    } else {
      root.setAttribute('data-theme', 'light');
      btn.textContent = 'Dark mode';
    }
  }

  var prefersDark = window.matchMedia &&
    window.matchMedia('(prefers-color-scheme: dark)').matches;
  apply(prefersDark ? 'dark' : 'light');

  btn.addEventListener('click', function () {
    var current = root.getAttribute('data-theme');
    apply(current === 'dark' ? 'light' : 'dark');
  });
})();
