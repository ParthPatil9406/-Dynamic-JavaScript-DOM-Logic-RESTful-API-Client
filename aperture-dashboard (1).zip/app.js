/**
 * app.js
 * DOM wiring for the Parts Catalog: fetch → filter → sort → render,
 * plus a localStorage-backed cart. Depends on api.js for all network I/O.
 */

import { fetchProducts, fetchCategories } from './api.js';

const CART_KEY = 'aperture_cart_v1';

const els = {
  grid: document.getElementById('catalogGrid'),
  skeleton: document.getElementById('catalogSkeleton'),
  errorBanner: document.getElementById('catalogError'),
  retryBtn: document.getElementById('catalogRetry'),
  search: document.getElementById('catalogSearch'),
  tabs: document.getElementById('catalogTabs'),
  sort: document.getElementById('catalogSort'),
  cartCount: document.getElementById('cartCount'),
};

const state = {
  allProducts: [],
  activeCategory: 'all',
  query: '',
  sort: 'default',
  cart: loadCart(),
};

/* ---------------------------------------------------------------- cart */

function loadCart() {
  try {
    const raw = localStorage.getItem(CART_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {}; // corrupted or unavailable storage — fail soft, start empty
  }
}

function saveCart() {
  try {
    localStorage.setItem(CART_KEY, JSON.stringify(state.cart));
  } catch {
    // storage full or disabled — cart still works for this session
  }
}

function addToCart(productId) {
  state.cart[productId] = (state.cart[productId] || 0) + 1;
  saveCart();
  renderCartCount();
}

function renderCartCount() {
  const total = Object.values(state.cart).reduce((sum, n) => sum + n, 0);
  els.cartCount.textContent = total;
  els.cartCount.hidden = total === 0;
}

/* ------------------------------------------------------------- loading */

function showSkeleton() {
  els.skeleton.hidden = false;
  els.grid.hidden = true;
  els.errorBanner.hidden = true;
}

function showError(message) {
  els.skeleton.hidden = true;
  els.grid.hidden = true;
  els.errorBanner.hidden = false;
  els.errorBanner.querySelector('.error-banner__message').textContent = message;
}

function showGrid() {
  els.skeleton.hidden = true;
  els.errorBanner.hidden = true;
  els.grid.hidden = false;
}

/* ------------------------------------------------------------ rendering */

function renderTabs(categories) {
  const all = ['all', ...categories];
  els.tabs.innerHTML = all
    .map(
      (cat) =>
        `<button class="tab" type="button" data-category="${cat}"
          aria-current="${cat === state.activeCategory ? 'page' : 'false'}">
          ${cat === 'all' ? 'All' : cat}
        </button>`
    )
    .join('');
}

function renderProducts(products) {
  if (products.length === 0) {
    els.grid.innerHTML = `<p class="catalog-empty">No items match your search.</p>`;
    return;
  }

  els.grid.innerHTML = products
    .map(
      (p) => `
      <article class="product-card">
        <img src="${p.image}" alt="${escapeHtml(p.title)}" loading="lazy">
        <p class="product-card__title">${escapeHtml(p.title)}</p>
        <p class="product-card__price">$${p.price.toFixed(2)}</p>
        <button class="product-card__add" type="button" data-id="${p.id}">Add to cart</button>
      </article>`
    )
    .join('');
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

/* -------------------------------------------------------------- filter */

function getVisibleProducts() {
  let list = state.allProducts;

  if (state.activeCategory !== 'all') {
    list = list.filter((p) => p.category === state.activeCategory);
  }

  if (state.query.trim()) {
    const q = state.query.trim().toLowerCase();
    list = list.filter((p) => p.title.toLowerCase().includes(q));
  }

  const sorted = [...list];
  if (state.sort === 'price-asc') sorted.sort((a, b) => a.price - b.price);
  if (state.sort === 'price-desc') sorted.sort((a, b) => b.price - a.price);
  if (state.sort === 'rating-desc') sorted.sort((a, b) => b.rating.rate - a.rating.rate);

  return sorted;
}

function refresh() {
  renderProducts(getVisibleProducts());
}

/* -------------------------------------------------------------- events */

function debounce(fn, delay) {
  let handle;
  return (...args) => {
    clearTimeout(handle);
    handle = setTimeout(() => fn(...args), delay);
  };
}

function bindEvents() {
  els.search.addEventListener(
    'input',
    debounce((e) => {
      state.query = e.target.value;
      refresh();
    }, 200)
  );

  els.tabs.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-category]');
    if (!btn) return;
    state.activeCategory = btn.dataset.category;
    [...els.tabs.children].forEach((el) =>
      el.setAttribute('aria-current', el === btn ? 'page' : 'false')
    );
    refresh();
  });

  els.sort.addEventListener('change', (e) => {
    state.sort = e.target.value;
    refresh();
  });

  els.grid.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-id]');
    if (!btn) return;
    addToCart(btn.dataset.id);
  });

  els.retryBtn.addEventListener('click', init);
}

/* ---------------------------------------------------------------- init */

async function init() {
  showSkeleton();
  try {
    const [products, categories] = await Promise.all([
      fetchProducts(),
      fetchCategories(),
    ]);
    state.allProducts = products;
    renderTabs(categories);
    refresh();
    showGrid();
  } catch (err) {
    showError(err.message);
  }
}

renderCartCount();
bindEvents();
init();
