/**
 * api.js
 * Thin async client around FakeStoreAPI (https://fakestoreapi.com).
 * Every function returns a Promise and throws a plain Error with a
 * user-readable message on failure, so callers only need one catch block.
 */

const API_BASE = 'https://fakestoreapi.com';

/**
 * Internal fetch wrapper: adds a timeout, checks response.ok, and
 * normalizes network / HTTP / parse failures into one Error shape.
 */
async function request(path, { timeoutMs = 8000 } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(`${API_BASE}${path}`, { signal: controller.signal });

    if (!res.ok) {
      throw new Error(`Request failed (${res.status} ${res.statusText})`);
    }

    return await res.json();
  } catch (err) {
    if (err.name === 'AbortError') {
      throw new Error('Request timed out — check your connection and try again.');
    }
    throw new Error(err.message || 'Network error — please try again.');
  } finally {
    clearTimeout(timer);
  }
}

/** Fetch every product. */
export async function fetchProducts() {
  return request('/products');
}

/** Fetch a single page/category of products. */
export async function fetchProductsByCategory(category) {
  return request(`/products/category/${encodeURIComponent(category)}`);
}

/** Fetch the list of available category names. */
export async function fetchCategories() {
  return request('/products/categories');
}
