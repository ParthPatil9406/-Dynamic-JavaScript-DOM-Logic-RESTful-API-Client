# Aperture — Responsive Dashboard

A mobile-first CSS architecture built on design tokens (CSS custom
properties), CSS Grid, and Flexbox. Demonstrated with a solar-fleet
monitoring dashboard.

## Files

- `index.html` — dashboard markup
- `style.css` — the token system + responsive grid architecture
- `theme.js` — dark/light theme toggle
- `api.js` — REST client for [FakeStoreAPI](https://fakestoreapi.com); every
  function returns a Promise and throws a plain `Error` with a readable
  message, so the caller only needs one `catch`
- `app.js` — DOM logic for the Parts Catalog: search, category tabs,
  sorting, a localStorage-backed cart, loading skeleton, and an error
  banner with retry. Loaded as an ES module (`<script type="module">`) and
  imports from `api.js`

## Parts catalog (dynamic JS + REST API)

- **Fetching**: `api.js` calls `GET /products` and `GET /products/categories`
  in parallel via `Promise.all`, with an `AbortController`-based timeout.
- **Filtering / sorting**: done client-side in `app.js` against the single
  in-memory product list — search (debounced 200ms), category tabs, and a
  sort select (price asc/desc, rating) all recompute and re-render without
  a page reload.
- **State caching**: cart contents persist to `localStorage` under
  `aperture_cart_v1` and reload on next visit; storage failures fail soft
  (cart still works for the session).
- **Loading / error states**: a shimmering skeleton grid shows while the
  initial fetch is in flight; a dismissable-by-retry error banner replaces
  it on failure, with a **Retry** button that re-runs `init()`.

To swap in a different public API, only `api.js` needs to change — `app.js`
consumes it through three functions (`fetchProducts`, `fetchProductsByCategory`,
`fetchCategories`) and doesn't know where the data comes from.

## Design tokens (`:root`)

| Group      | Tokens |
|------------|--------|
| Color      | `--color-ink`, `--color-canvas`, `--color-brand`, `--color-brand-2`, `--ok`, `--warn` (aliased to semantic `--bg`, `--surface`, `--text`, `--accent`, etc. so theming only touches the aliases) |
| Type       | `--font-display` (Fraunces, for data figures), `--font-body` (IBM Plex Sans), `--step-0` … `--step-4` type scale |
| Spacing    | `--space-1` … `--space-7`, 4px base |
| Radius     | `--radius-sm/md/lg` |
| Elevation  | `--shadow-soft`, `--shadow-lift` |

## Breakpoints

| Width    | Layout change |
|----------|---------------|
| 320px    | Single column, stacked nav, floor styles for very small phones at ≤360px |
| 768px    | Nav becomes a left rail; `.shell` goes to a 2-column grid |
| 1024px   | `.main` splits into a 2fr/1fr grid (site table + alerts panel) |
| 1440px   | Content is capped and centered with wider gutters |

The card grid (`.card-grid`) uses `repeat(auto-fit, minmax(240px, 1fr))`
so it stays fluid *between* the named breakpoints too, not just at them.

## Dark / light mode

Theming is driven entirely by re-pointing the semantic aliases
(`--bg`, `--surface`, `--text`, `--accent`, …) under:

- `@media (prefers-color-scheme: dark)` — respects OS setting
- `:root[data-theme="dark"]` / `[data-theme="light"]` — manual override,
  toggled by the button in the header (see `app.js`)

## Testing for horizontal overflow

- `box-sizing: border-box` globally
- `min-width: 0` on grid children (prevents content from forcing track width)
- Wide content (the site-status table) scrolls inside its own
  `.panel { overflow-x: auto }` container instead of widening the page
- `body { overflow-x: hidden }` as a final guard

To verify: open `index.html` and resize the viewport through 320 / 768 /
1024 / 1440px, or use your browser's device toolbar — no horizontal
scrollbar should appear at any width.

## Screenshots

Add mobile / tablet / desktop screenshots here before submitting:

```
screenshots/
  mobile-320.png
  tablet-768.png
  desktop-1440.png
```
